// Bump this when you change index.html so clients pick up the new version.
const CACHE_VERSION = 'qr-fountain-v1';

const APP_SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png',
  './icon-maskable-512.png',
];

// Known library entry points — precached on install. Any *other* resource
// these pull in at runtime (e.g. the zxing/ggwave .wasm binaries themselves)
// gets cached opportunistically the first time it's actually fetched, via
// the fetch handler below, so the app keeps working offline after one
// successful online run.
const LIBRARY_SHELL = [
  'https://cdn.jsdelivr.net/npm/zxing-wasm@2.2.1/dist/iife/reader/index.js',
  'https://cdn.jsdelivr.net/npm/ggwave/ggwave.js',
  'https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.js',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_VERSION).then((cache) =>
      // Precache what we can; don't let one failed cross-origin fetch block install.
      Promise.allSettled(
        [...APP_SHELL, ...LIBRARY_SHELL].map((url) =>
          cache.add(url).catch((err) => console.warn('[sw] precache failed', url, err))
        )
      )
    ).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_VERSION).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (event) => {
  if (event.request.method !== 'GET') return;

  event.respondWith(
    caches.match(event.request).then((cached) => {
      const network = fetch(event.request)
        .then((response) => {
          // Cache a copy of anything that loads successfully (app shell,
          // CDN libraries, and the wasm binaries they fetch at runtime),
          // so a later offline run still has it.
          if (response && response.ok) {
            const copy = response.clone();
            caches.open(CACHE_VERSION).then((cache) => cache.put(event.request, copy));
          }
          return response;
        })
        .catch(() => cached); // offline and not cached — nothing more we can do

      // Cache-first for speed and offline reliability; falls back to network.
      return cached || network;
    })
  );
});
