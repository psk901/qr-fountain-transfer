# QR Fountain Transfer — GitHub APK Build

1. Create a GitHub repository and upload all files in this folder to the `main` branch.
2. Open **Actions** and select **Build APK and Deploy PWA**.
3. The workflow deploys the PWA, builds a signed Android APK and AAB, generates Digital Asset Links, then redeploys Pages.
4. Download `qr-fountain-transfer-android` from the workflow run under **Artifacts**.

Optional for a persistent Google Play signing identity: add repository secrets `BUBBLEWRAP_KEYSTORE_PASSWORD` and `BUBBLEWRAP_KEY_PASSWORD`. The current workflow otherwise uses a CI-only key, suitable for testing.
