package com.shiva.duobeam

import android.annotation.SuppressLint
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.graphics.Bitmap
import android.graphics.Matrix
import android.graphics.Point
import android.os.SystemClock
import android.util.Size
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.concurrent.thread
import kotlin.math.max

/** Camera (QR) and microphone (ultrasound) both feed ONE fountain decoder. */
class Receiver(
    private val act: AppCompatActivity,
    private val view: PreviewView,
    private val useAudio: Boolean
) {
    @Volatile var result: ByteArray? = null
    @Volatile var error: String? = null
    @Volatile private var running = false
    @Volatile private var qrPk = 0
    @Volatile private var auPk = 0
    @Volatile private var coPk = 0
    private val busy = AtomicBoolean(false)
    @Volatile private var solved = 0
    @Volatile private var k = 0
    @Volatile private var t0 = 0L
    @Volatile private var mic = if (useAudio) "starting" else "no permission"

    private var dec: Fountain.Decoder? = null
    private val exec = Executors.newSingleThreadExecutor()
    private var provider: ProcessCameraProvider? = null
    private val scanner = BarcodeScanning.getClient(
        BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
    )

    fun start() {
        running = true
        startCamera()
        if (useAudio) startAudio()
    }

    fun stop() {
        running = false
        try { provider?.unbindAll() } catch (e: Exception) { }
        try { scanner.close() } catch (e: Exception) { }
        exec.shutdown()
    }

    fun statusText(): String =
        "Blocks $solved/$k (${rate()})   QR packets $qrPk   color packets $coPk   audio packets $auPk   mic: $mic" +
            (error?.let { "\n$it" } ?: "")

    private fun rate(): String {
        if (t0 == 0L) return "0 KB/s"
        val s = (SystemClock.elapsedRealtime() - t0) / 1000.0
        return "%.1f KB/s".format(solved * Fountain.BLOCK / 1024.0 / maxOf(s, 0.5))
    }

    fun progressPermille(): Int = if (k == 0) 0 else solved * 1000 / k

    @androidx.annotation.OptIn(ExperimentalGetImage::class)
    private fun startCamera() {
        val f = ProcessCameraProvider.getInstance(act)
        f.addListener({
            val p = f.get()
            provider = p
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
            val selector = ResolutionSelector.Builder()
                .setResolutionStrategy(
                    ResolutionStrategy(Size(1920, 1080), ResolutionStrategy.FALLBACK_RULE_CLOSEST_HIGHER_THEN_LOWER)
                ).build()
            val an = ImageAnalysis.Builder()
                .setResolutionSelector(selector)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
            an.setAnalyzer(exec) { px ->
                if (!running || !busy.compareAndSet(false, true)) {
                    px.close()
                } else {
                    val bmp = try { rotated(px.toBitmap(), px.imageInfo.rotationDegrees) }
                              catch (e: Exception) { null } finally { px.close() }
                    if (bmp == null) busy.set(false)
                    else scanner.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener(exec) { codes ->
                            for (c in codes) {
                                val raw = c.rawBytes ?: c.rawValue?.toByteArray(Charsets.ISO_8859_1) ?: continue
                                onQr(raw)
                                val pts = c.cornerPoints
                                if (raw.size == Fountain.PKT + 1 && raw[Fountain.PKT] == 1.toByte() && pts != null)
                                    try { sampleGrid(bmp, pts) } catch (e: Exception) { }
                            }
                        }
                        .addOnCompleteListener(exec) { busy.set(false) }
                }
            }
            p.unbindAll()
            p.bindToLifecycle(act, CameraSelector.DEFAULT_BACK_CAMERA, preview, an)
        }, ContextCompat.getMainExecutor(act))
    }

    private fun rotated(b: Bitmap, deg: Int): Bitmap =
        if (deg == 0) b else Bitmap.createBitmap(b, 0, 0, b.width, b.height, Matrix().apply { postRotate(deg.toFloat()) }, false)

    /** Sample the colour grid using the finder QR corners as a perspective reference. */
    private fun sampleGrid(bmp: Bitmap, c: Array<Point>) {
        if (c.size < 4) return
        val dst = FloatArray(8)
        for (i in 0 until 4) { dst[2 * i] = c[i].x.toFloat(); dst[2 * i + 1] = c[i].y.toFloat() }
        val mat = Matrix()
        if (!mat.setPolyToPoly(ColorGrid.finderSrc, 0, dst, 0, 4)) return
        val n = ColorGrid.N
        val p = FloatArray(2)
        val rgb = IntArray(n * n)
        for (r in 0 until n) for (cc in 0 until n) {
            p[0] = ColorGrid.GX + (cc + 0.5f) * ColorGrid.CELL
            p[1] = ColorGrid.GY + (r + 0.5f) * ColorGrid.CELL
            mat.mapPoints(p)
            val x = p[0].toInt(); val y = p[1].toInt()
            if (x < 1 || y < 1 || x >= bmp.width - 1 || y >= bmp.height - 1) return
            var rs = 0; var gs = 0; var bs = 0
            for (dy in -1..1) for (dx in -1..1) {
                val v = bmp.getPixel(x + dx, y + dy)
                rs += (v shr 16) and 255; gs += (v shr 8) and 255; bs += v and 255
            }
            rgb[r * n + cc] = ((rs / 9) shl 16) or ((gs / 9) shl 8) or (bs / 9)
        }
        val sum = Array(8) { IntArray(4) }
        for (cc in 0 until n) {
            val v = rgb[cc]; val s = sum[cc and 7]
            s[0] += (v shr 16) and 255; s[1] += (v shr 8) and 255; s[2] += v and 255; s[3]++
        }
        val ref = Array(8) { i -> IntArray(3) { j -> sum[i][j] / sum[i][3] } }
        val idx = IntArray(n * (n - 1))
        for (i in idx.indices) {
            val v = rgb[n + i]
            val r = (v shr 16) and 255; val g = (v shr 8) and 255; val b = v and 255
            var best = 0; var bd = Int.MAX_VALUE
            for (k2 in 0 until 8) {
                val dr = r - ref[k2][0]; val dg = g - ref[k2][1]; val db = b - ref[k2][2]
                val d = dr * dr + dg * dg + db * db
                if (d < bd) { bd = d; best = k2 }
            }
            idx[i] = best
        }
        val bytes = ColorGrid.fromCells(idx)
        for (i in 0 until ColorGrid.PKTS) Fountain.parse(bytes, i * Fountain.PKT)?.let { add(it, 2) }
    }

    private fun onQr(raw: ByteArray) {
        var o = 0
        while (o + Fountain.PKT <= raw.size) {
            Fountain.parse(raw, o)?.let { add(it, 0) }
            o += Fountain.PKT
        }
    }

    @SuppressLint("MissingPermission")
    private fun startAudio() {
        thread(name = "mic-rx") {
            val min = AudioRecord.getMinBufferSize(Modem.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            var r: AudioRecord? = null
            for (src in intArrayOf(MediaRecorder.AudioSource.UNPROCESSED, MediaRecorder.AudioSource.MIC)) {
                try {
                    val c = AudioRecord(src, Modem.SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, max(min, Modem.SR))
                    if (c.state == AudioRecord.STATE_INITIALIZED) { r = c; break } else c.release()
                } catch (e: Exception) { }
            }
            if (r == null) { mic = "unavailable"; return@thread }
            r.startRecording()
            mic = "listening"
            val demod = Modem.Demod { p -> add(p, 1) }
            val buf = ShortArray(2048)
            while (running) {
                val n = r.read(buf, 0, buf.size)
                if (n > 0) demod.feed(buf, n) else if (n < 0) break
            }
            try { r.stop() } catch (e: Exception) { }
            r.release()
        }
    }

    @Synchronized
    private fun add(p: Fountain.Packet, src: Int) {
        if (result != null) return
        if (t0 == 0L) t0 = SystemClock.elapsedRealtime()
        var d = dec
        if (d == null) {
            d = Fountain.Decoder(p.fileId, p.fileLen)
            dec = d
            k = d.k
        }
        if (p.fileId != d.fileId || p.fileLen != d.len) return
        if (!d.has(p.seed)) { when (src) { 0 -> qrPk++; 1 -> auPk++; else -> coPk++ } }
        val done = d.add(p.seed, p.payload)
        solved = d.solved
        if (done) {
            val c = d.result()
            if (c != null) result = c
            else { error = "Checksum mismatch - restarting"; dec = null; solved = 0; k = 0 }
        }
    }
}
