package com.shiva.duobeam

import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.common.BitMatrix
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.Random

/**
 * 8-colour grid (3 bits per cell). A small "finder" QR above the grid gives position/rotation/perspective
 * (via ML Kit corner points). Row 0 of the grid shows the 8 palette colours so the receiver can
 * calibrate to the real camera colours; every other cell is classified to the nearest reference.
 */
object ColorGrid {
    const val N = 72
    const val CELL = 13
    const val PKTS = 7
    const val W = 960
    const val H = 1320
    const val QS = 360
    const val QX = 300
    const val QY = 0
    const val GX = 12
    const val GY = 380
    private const val DATA_CELLS = (N - 1) * N
    const val CAP = DATA_CELLS * 3 / 8

    val PALETTE = IntArray(8) {
        (0xFF shl 24) or (if (it and 1 != 0) 0xFF0000 else 0) or
            (if (it and 2 != 0) 0x00FF00 else 0) or (if (it and 4 != 0) 0x0000FF else 0)
    }
    private val white = ByteArray(CAP).also { Random(0xD0B3AL).nextBytes(it) }
    private val hints = mapOf<EncodeHintType, Any>(
        EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L,
        EncodeHintType.CHARACTER_SET to "ISO-8859-1",
        EncodeHintType.MARGIN to 2
    )

    fun finderMatrix(raw: ByteArray): BitMatrix =
        QRCodeWriter().encode(String(raw, Charsets.ISO_8859_1), BarcodeFormat.QR_CODE, QS, QS, hints)

    /** Canvas coordinates of the finder QR symbol corners: TL, TR, BR, BL. */
    val finderSrc: FloatArray by lazy {
        val m = finderMatrix(ByteArray(Fountain.PKT + 1))
        var x0 = QS; var y0 = QS; var x1 = -1; var y1 = -1
        for (y in 0 until QS) for (x in 0 until QS) if (m.get(x, y)) {
            if (x < x0) x0 = x; if (x > x1) x1 = x
            if (y < y0) y0 = y; if (y > y1) y1 = y
        }
        floatArrayOf(
            (QX + x0).toFloat(), (QY + y0).toFloat(), (QX + x1 + 1).toFloat(), (QY + y0).toFloat(),
            (QX + x1 + 1).toFloat(), (QY + y1 + 1).toFloat(), (QX + x0).toFloat(), (QY + y1 + 1).toFloat()
        )
    }

    /** Bytes (<= CAP) -> palette index per cell (N*N, row 0 = reference row). */
    fun toCells(data: ByteArray): IntArray {
        val buf = white.copyOf()
        for (i in data.indices) buf[i] = (buf[i].toInt() xor data[i].toInt()).toByte()
        val cells = IntArray(N * N)
        for (c in 0 until N) cells[c] = c and 7
        for (i in 0 until DATA_CELLS) {
            var v = 0
            for (b in 0 until 3) {
                val bit = i * 3 + b
                v = (v shl 1) or ((buf[bit shr 3].toInt() shr (7 - (bit and 7))) and 1)
            }
            cells[N + i] = v
        }
        return cells
    }

    /** Palette indices of the data cells (DATA_CELLS) -> bytes (CAP). */
    fun fromCells(cells: IntArray): ByteArray {
        val buf = ByteArray(CAP)
        for (i in 0 until DATA_CELLS) for (b in 0 until 3) {
            if (((cells[i] shr (2 - b)) and 1) == 1) {
                val bit = i * 3 + b
                buf[bit shr 3] = (buf[bit shr 3].toInt() or (1 shl (7 - (bit and 7)))).toByte()
            }
        }
        for (i in buf.indices) buf[i] = (buf[i].toInt() xor white[i].toInt()).toByte()
        return buf
    }

    fun paint(px: IntArray, cells: IntArray) {
        for (r in 0 until N) for (c in 0 until N) {
            val col = PALETTE[cells[r * N + c]]
            val ox = GX + c * CELL
            val oy = GY + r * CELL
            for (y in 0 until CELL) { val row = (oy + y) * W + ox; for (x in 0 until CELL) px[row + x] = col }
        }
    }
}
