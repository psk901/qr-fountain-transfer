package com.shiva.duobeam

import android.graphics.Bitmap
import android.graphics.Color
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.SystemClock
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import kotlin.concurrent.thread
import kotlin.math.max

/** Streams one endless fountain stream over BOTH channels at once: QR frames (colour grid + finder QR, or 1/2/4 raw-binary tiles) and ultrasound (1 packet per burst). */
class Sender(container: ByteArray) {
    private val enc = Fountain.Encoder(container)
    val blocks get() = enc.k

    @Volatile var running = false
    @Volatile var qrOn = true
    @Volatile var audioOn = true
    @Volatile var fps = 10
    @Volatile var tiles = 0   // 0 = colour grid + finder QR, else 1/2/4 plain QR tiles
    @Volatile var qrFrames = 0
    @Volatile var audioFrames = 0
    @Volatile var bitmap: Bitmap? = null

    fun start() {
        running = true
        thread(name = "qr-tx") { qrLoop() }
        thread(name = "audio-tx") { audioLoop() }
    }

    fun stop() { running = false }

    private fun colorFrame(): Bitmap {
        val W = ColorGrid.W
        val px = IntArray(W * ColorGrid.H) { Color.WHITE }
        val fin = ByteArray(Fountain.PKT + 1)
        enc.next().copyInto(fin)
        fin[Fountain.PKT] = 1                       // marks "colour-grid finder"
        val m = ColorGrid.finderMatrix(fin)
        for (y in 0 until ColorGrid.QS) for (x in 0 until ColorGrid.QS) {
            if (m.get(x, y)) px[(ColorGrid.QY + y) * W + ColorGrid.QX + x] = Color.BLACK
        }
        val data = ByteArray(ColorGrid.PKTS * Fountain.PKT)
        for (i in 0 until ColorGrid.PKTS) enc.next().copyInto(data, i * Fountain.PKT)
        ColorGrid.paint(px, ColorGrid.toCells(data))
        return Bitmap.createBitmap(px, W, ColorGrid.H, Bitmap.Config.ARGB_8888)
    }

    private fun qrLoop() {
        val writer = QRCodeWriter()
        val hints = mapOf<EncodeHintType, Any>(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.L, // fountain layer already handles loss
            EncodeHintType.CHARACTER_SET to "ISO-8859-1",              // 1 char = 1 byte -> raw binary QR
            EncodeHintType.MARGIN to 2
        )
        val total = 960
        while (running) {
            val t0 = SystemClock.elapsedRealtime()
            if (qrOn) {
                try {
                    val n = tiles
                    if (n == 0) { bitmap = colorFrame(); qrFrames++ } else {
                    val per = if (n >= 2) 2 else 3
                    val cols = if (n <= 1) 1 else 2
                    val rows = (n + cols - 1) / cols
                    val tile = total / cols
                    val w = tile * cols
                    val h = tile * rows
                    val px = IntArray(w * h) { Color.WHITE }
                    for (t in 0 until n) {
                        val raw = ByteArray(Fountain.PKT * per)
                        for (i in 0 until per) enc.next().copyInto(raw, i * Fountain.PKT)
                        val m = writer.encode(String(raw, Charsets.ISO_8859_1), BarcodeFormat.QR_CODE, tile, tile, hints)
                        val ox = (t % cols) * tile
                        val oy = (t / cols) * tile
                        for (y in 0 until tile) for (x in 0 until tile) {
                            if (m.get(x, y)) px[(oy + y) * w + ox + x] = Color.BLACK
                        }
                    }
                    bitmap = Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888)
                    qrFrames++
                    }
                } catch (e: Exception) { /* skip frame */ }
            }
            val wait = 1000L / max(1, fps) - (SystemClock.elapsedRealtime() - t0)
            if (wait > 0) try { Thread.sleep(wait) } catch (e: InterruptedException) { }
        }
    }

    private fun audioLoop() {
        val min = AudioTrack.getMinBufferSize(Modem.SR, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val track = try {
            AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(Modem.SR)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(max(min, Modem.SR))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
        } catch (e: Exception) { return }
        track.play()
        while (running) {
            if (!audioOn) {
                try { Thread.sleep(100) } catch (e: InterruptedException) { }
                continue
            }
            val pcm = Modem.modulate(enc.next())
            track.write(pcm, 0, pcm.size) // blocking
            audioFrames++
        }
        try { track.stop() } catch (e: Exception) { }
        track.release()
    }

}
